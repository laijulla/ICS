void main ( )
{
	int i , j , k ;
	i = 0 ;
	k = i + j ;
}
